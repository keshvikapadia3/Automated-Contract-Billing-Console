import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface AuthState {
  isLoggedIn: boolean;
  username: string;
  token: string;
}

const initialState: AuthState = {
  isLoggedIn: false,
  username: "",
  token: "",
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    login(
      state,
      action: PayloadAction<{
        username: string;
        token: string;
      }>
    ) {
      state.isLoggedIn = true;
      state.username = action.payload.username;
      state.token = action.payload.token;
    },

    logout(state) {
      state.isLoggedIn = false;
      state.username = "";
      state.token = "";
    },
  },
});

export const { login, logout } = authSlice.actions;
export default authSlice.reducer;