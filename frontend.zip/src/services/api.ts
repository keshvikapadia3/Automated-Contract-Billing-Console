import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8000",
  headers: {
    "Content-Type": "application/json",
  },
});

// AUTH
export const loginUser = (data: any) =>
  api.post("/auth/login", data);

// CONTRACTS
export const getContracts = () =>
  api.get("/contracts");

export const createContract = (data: any) =>
  api.post("/contracts", data);

// POINTS
export const getPoints = () =>
  api.get("/points");

export const createPoint = (data: any) =>
  api.post("/points", data);

// INVOICES
export const getInvoices = () =>
  api.get("/invoices");

export default api;
